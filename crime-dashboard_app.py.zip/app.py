import streamlit as st
st.title('India Crime Dashboard (Template)')
st.write('Replace CSVs and models in this folder to enable full functionality.')