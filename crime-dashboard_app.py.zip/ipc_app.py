import streamlit as st
st.title('IPC Crimes Explorer (Template)')
st.write('Place ipc_ncrb_data.csv and models in the repo root or models/ folder.')