import streamlit as st
st.title('SLL Crimes Explorer (Template)')
st.write('Place sll_ncrb_data.csv and models in the repo root or models/ folder.')